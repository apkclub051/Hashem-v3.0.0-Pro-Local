#!/usr/bin/env bash
# Hashem v3.0.0 Community bootstrap. Run from the extracted package.
set -euo pipefail
bundle=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd "$bundle"
for item in gre-panel hashem.sh grepanel hashem-customer.sh SHA256SUMS install.sh; do
    [[ -f "$item" ]] || { echo "Missing package file: $item" >&2; exit 1; }
done
sha256sum -c SHA256SUMS
bash -n hashem.sh
bash -n grepanel
[[ "$(uname -s)" == Linux && "$(uname -m)" == x86_64 ]] || { echo 'Linux amd64 is required.' >&2; exit 1; }
[[ "$(head -c 4 gre-panel)" == $'\177ELF' ]] || { echo 'Invalid executable.' >&2; exit 1; }
if [[ "${1:-}" == --check ]]; then
    echo 'Package integrity and shell syntax OK. No installation performed.'
    exit 0
fi
[[ $EUID -eq 0 ]] || { echo 'Run as root: sudo bash install.sh' >&2; exit 1; }
command -v systemctl >/dev/null || { echo 'A Linux server with systemd is required.' >&2; exit 1; }
[[ "$(./gre-panel version)" == v3.0.0-community-pro1 ]] || { echo 'Unexpected panel build.' >&2; exit 1; }
./gre-panel license check sentinel
destination=/opt/hashem-community/v3.0.0
mkdir -p "$destination" /usr/local/bin
if [[ "$bundle" != "$destination" ]]; then
    for item in gre-panel hashem.sh grepanel hashem-customer.sh install.sh SHA256SUMS; do
        install -m 0644 "$item" "$destination/$item"
    done
fi
chmod 0755 "$destination/gre-panel" "$destination/hashem.sh" "$destination/grepanel" "$destination/hashem-customer.sh" "$destination/install.sh"
was_running=0
systemctl is-active --quiet gre-panel 2>/dev/null && was_running=1
previous=""
if [[ -f /usr/local/bin/gre-panel ]]; then
    previous="/usr/local/bin/gre-panel.before-community-$(date -u +%Y%m%dT%H%M%SZ)"
    cp -p /usr/local/bin/gre-panel "$previous"
fi
install -m 0755 "$destination/gre-panel" /usr/local/bin/gre-panel.community-new
mv -f /usr/local/bin/gre-panel.community-new /usr/local/bin/gre-panel
install -m 0755 "$destination/hashem.sh" /usr/local/bin/hashem
install -m 0755 "$destination/hashem.sh" /usr/local/bin/hashem.sh
install -m 0755 "$destination/grepanel" /usr/local/bin/grepanel
ln -sf /usr/local/bin/hashem.sh /usr/local/bin/gre.sh
if [[ "$was_running" == 1 ]]; then
    if ! systemctl restart gre-panel; then
        if [[ -n "$previous" ]]; then
            install -m 0755 "$previous" /usr/local/bin/gre-panel.community-rollback
            mv -f /usr/local/bin/gre-panel.community-rollback /usr/local/bin/gre-panel
            systemctl restart gre-panel || true
        fi
        echo 'Panel restart failed; previous binary restored when available. Inspect journalctl -u gre-panel.' >&2
        exit 1
    fi
fi
echo 'Hashem Community installed. Opening the original setup manager...'
exec bash /usr/local/bin/hashem "$@"
